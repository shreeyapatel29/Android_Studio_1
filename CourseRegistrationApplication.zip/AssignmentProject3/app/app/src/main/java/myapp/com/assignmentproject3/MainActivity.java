package myapp.com.assignmentproject3;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewPager vp = (ViewPager) findViewById(R.id.view_pager);
        TabLayout tl = (TabLayout) findViewById(R.id.tab_layout);
        FragmentAdapter pa = new FragmentAdapter(getSupportFragmentManager(), 2);
        vp.setAdapter(pa);
        tl.setupWithViewPager(vp);

        }
    }

