package myapp.com.assignmentproject3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class MyDatabaseHandler extends SQLiteOpenHelper {


    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "collegeDb";

    // Contacts table name
    private static final String TABLE_COURSE = "collegeTablecourses";

    // Courses Table Columns names
    private static final String INT_ID = "INT_ID";
    private static final String COURSE_ID_DATA = "COURSE_ID_DATA";
    private static final String COURSE_INFO = "COURSE_INFO";
    private static final String COURSE_TERM = "COURSE_TERM";
    private static  final String COURSE_TERMONE="COURSE_TERMONE";
    private static  final String COURSE_TERMTWO="COURSE_TERMTWO";

    public MyDatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_COURSE + "("
                + INT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COURSE_INFO + " TEXT,"
                + COURSE_ID_DATA + " TEXT,"
                + COURSE_TERMONE + " TEXT,"
                + COURSE_TERMTWO + " TEXT,"
                + COURSE_TERM + " TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSE);
        // Creating tables again
        onCreate(db);
    }

    // Adding new CourseModels
    public void addcourse(CourseModels Course) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COURSE_INFO, Course.getCOURSE_DESC());
        values.put(COURSE_TERM, Course.getTerm());
        values.put(COURSE_ID_DATA,Course.getCOURSEID());
        values.put(COURSE_TERMONE,Course.getCOURSEPERREQUITES1());
        values.put(COURSE_TERMTWO,Course.getCOURSEPREREQUIEST2());

        db.insert(TABLE_COURSE, null, values);
        db.close(); // Closing database connection
    }

    // Getting one CourseModels
    public CourseModels getcourse(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_COURSE, new String[]{COURSE_ID_DATA,
                        COURSE_INFO, COURSE_TERM}, COURSE_ID_DATA + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        CourseModels contact = new CourseModels((cursor.getString(0)),
                cursor.getString(1), cursor.getString(2),cursor.getString(3),cursor.getString(4));
        // return CourseModels
        return contact;
    }


    public List<CourseModels> getallcourses() {
        List<CourseModels> CourseList = new ArrayList<CourseModels>();
        // Select All Query
      //  String selectQuery = "SELECT  * FROM " + TABLE_COURSE;
        String selectQuery1 = "SELECT * FROM " + TABLE_COURSE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery1, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                CourseModels Course = new CourseModels();
                Course.setTerm(cursor.getString(5));
                Course.setCOURSE_DESC(cursor.getString(1));
                Course.setCOURSEPERREQUITES1(cursor.getString(4));
                Course.setCOURSEID(cursor.getString(2));
              Course.setCOURSEPREREQUIEST2(cursor.getString(3));

                // Adding contact to list
                CourseList.add(Course);
            } while (cursor.moveToNext());
        }

        // return contact list
        return CourseList;
    }

    // Getting Courses Count
    public int getCoursesCount() {
        String countQuery = "SELECT  * FROM " + TABLE_COURSE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }

    // Deleting a CourseModels
    public void deletecourse(String Course) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_COURSE, COURSE_ID_DATA + " = ?",
                new String[] { String.valueOf(Course) });
        db.close();
    }
}
