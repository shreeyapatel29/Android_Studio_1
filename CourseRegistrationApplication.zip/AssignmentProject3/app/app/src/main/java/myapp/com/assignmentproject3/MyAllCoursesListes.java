package myapp.com.assignmentproject3;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MyAllCoursesListes extends Fragment {
    View view = null;

    ArrayList<CourseModels> arraylist = new ArrayList<>();
    private RecycleerAdapter recyleAdapterdata;

    public MyAllCoursesListes() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_allcourses, container, false);
        recyleAdapterdata = new RecycleerAdapter(arraylist);
        preparecourseData();
        RecyclerView recyvleview = (RecyclerView) view.findViewById(R.id.courselv);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(getContext());
        recyvleview.setHasFixedSize(true);
        recyvleview.setLayoutManager(lm);
        recyvleview.setAdapter(recyleAdapterdata);


        recyvleview.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyvleview, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                CourseModels cInfo = arraylist.get(position);
                Toast.makeText(getActivity(), cInfo.getCOURSE_DESC() + " is selected!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity().getApplication(), CourseDeatilsActivityFull.class);



                intent.putExtra("COURSE_DESC",cInfo.getCOURSE_DESC());
                intent.putExtra("COURSEID",cInfo.getCOURSEID());
                intent.putExtra("course_term",cInfo.getTerm());
                intent.putExtra("COURSEPERREQUITES1",cInfo.getCOURSEPERREQUITES1());
                intent.putExtra("COURSEPREREQUIEST2",cInfo.getCOURSEPREREQUIEST2());
                intent.putExtra("condi",cInfo.getCondition());
                startActivity(intent);

                getActivity().finish();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        preparecourseData();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    private void preparecourseData() {
        CourseModels COURSEONE=new CourseModels("Introduction to Coding", "2nd term",
                "NAN", "CS128", "NAN");
        arraylist.add(COURSEONE);
        CourseModels coursetwo=new CourseModels("Introducing to Programming", "1st term",
                "NAN", "CS161", "NAN");
        arraylist.add(coursetwo);
        CourseModels coursethree=new CourseModels("Programming on Datastructure", "2nd term",
                "CS161", "CS162", "NAN");
        arraylist.add(coursethree);
        CourseModels coursefour=new CourseModels("Social Issues", "2nd term",
                "NAN", "CS215", "NAN");
        arraylist.add(coursefour);
        CourseModels coursefive=new CourseModels("Health Analysis", "1st term",
                "CS161", "CS225", "CS128");
        arraylist.add(coursefive);
        CourseModels coursesix=new CourseModels("Data Science", "1st term",
                "CS161", "CS223", "NAN");
        arraylist.add(coursesix);
        CourseModels courseseven=new CourseModels("Advanced Data structure", "1st term",
                "CS162", "CS255", "NAN");
        arraylist.add(courseseven);
        CourseModels coursenine=new CourseModels("Computer Architecture", "2nd term",
                "CS255", "CS263", "NAN");
        arraylist.add(coursenine);
        CourseModels courseren=new CourseModels("DataBase Managment System", "2nd term",
                "CS162", "CS275", "NAN");
        arraylist.add(courseren);
        CourseModels coutse11=new CourseModels("Discrete Structure", "1st term",
                "Math101", "CS277", "CS162");
        arraylist.add(coutse11);
        CourseModels course12=new CourseModels("Evolutionary computation", "1st term",
                "NAN", "CS340", "NAN");
        arraylist.add(course12);
        CourseModels course13=new CourseModels("Theory of Computing", "1st term",
                "CS255", "CS356", "CS277");
        arraylist.add(course13);
        CourseModels courese14=new CourseModels("Theory of Computing", "2nd term",
                "CS255", "CS356", "CS277");
        arraylist.add(courese14);
         CourseModels course15=new CourseModels("Mobile app Devlopement", "1st term",
                "CS162", "CS364", "NAN");
        arraylist.add(course15);
        CourseModels course16=new CourseModels("Data Communication and Networking", "1st term",
                "CS255", "CS368", "NAN");
        arraylist.add(course16);
        CourseModels course17=new CourseModels("Operating Systems", "1st term",
                "CS255", "CS375", "NAN");
        arraylist.add(course17);
        CourseModels course18=new CourseModels("Math", "1st term",
                "NAN", "CS101", "NAN");
        arraylist.add(course18);
        recyleAdapterdata.notifyDataSetChanged();
    }

}
