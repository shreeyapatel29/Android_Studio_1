package myapp.com.assignmentproject3;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class FragmentAdapter extends FragmentPagerAdapter {
    int noOfages;

    public FragmentAdapter(FragmentManager fm, int numpages){
        super(fm);
        noOfages = numpages;
    }

    public int getCount() {
        return noOfages;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new MyAllCoursesListes();
            case 1:
                return new AllAddedCoursesFragment();
                default:
                    return null;
    }
    }
    public CharSequence getPageTitle(int position) {
        switch (position) {

            case 0:
                return new String("My Courses      ");
            case 1:
                return new String("ENROLLED courses    ");
            default:
                return null;

        }
}}
