package myapp.com.assignmentproject3;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public class RecycleerAdapter extends RecyclerView.Adapter<RecycleerAdapter.MyViewHolder> {

    private List<CourseModels> courseList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView courseId, courseName, coursterm;

        public MyViewHolder(View view) {
            super(view);
            courseId = (TextView) view.findViewById(R.id.courseId);
            courseName = (TextView) view.findViewById(R.id.courseName);
            coursterm = (TextView) view.findViewById(R.id.coursterm);
        }
    }


    public RecycleerAdapter(List<CourseModels> courseList) {
        this.courseList = courseList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recykleinside, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        CourseModels course = courseList.get(position);
        holder.courseId.setText(course.getCOURSEID());
        holder.courseName.setText(course.getCOURSE_DESC());
        holder.coursterm.setText(course.getTerm());
    }

    @Override
    public int getItemCount() {
        return courseList.size();
    }
}
