package myapp.com.assignmentproject3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;


public class CourseDeatilsActivityFull extends AppCompatActivity implements android.view.View.OnClickListener {
   // CourseModels courses;
    TextView courseId, detailsdesc, termdetails, termpre1, termpre2, condition;
    Button addtodb, emovedatbase, View;
    String course_Id, course_des, course_term, prerequisite1, prerequisite2, condi, term;
    String courseImg;
    Boolean deleteFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_description);
        courseId = findViewById(R.id.CourseId);
        detailsdesc = findViewById(R.id.coursedesc);
        termdetails = findViewById(R.id.courseterm);
        termpre1 = findViewById(R.id.termpre1);
        termpre2 = findViewById(R.id.termpre2);
        condition = findViewById(R.id.condition);
        addtodb = findViewById(R.id.addtodb);
        emovedatbase = findViewById(R.id.emovedatbase);
        ImageView crImg = findViewById(R.id.cr_img);
        Picasso.get().load(courseImg).into(crImg);

//        getting the string from the mainactivity
        course_Id = getIntent().getStringExtra("COURSEID");
        course_des = getIntent().getStringExtra("COURSE_DESC");
        course_term = getIntent().getStringExtra("course_term");
        prerequisite1 = getIntent().getStringExtra("COURSEPERREQUITES1");
        prerequisite2 = getIntent().getStringExtra("COURSEPREREQUIEST2");
        condi = getIntent().getStringExtra("condi");
        courseImg = getIntent().getStringExtra("COURSE_IMG");


        courseId.setText(course_Id);
        detailsdesc.setText(course_des);
        termdetails.setText(course_term);
        termpre1.setText(prerequisite1);
        termpre2.setText(prerequisite2);
        addtodb.setOnClickListener(this);
        emovedatbase.setOnClickListener(this);

    }

    @Override
    public void onClick(android.view.View view) {
        CourseModels courses = new CourseModels(course_des, course_term, prerequisite1, course_Id, prerequisite2);
        MyDatabaseHandler myDatabaseHandler = new MyDatabaseHandler(this);

                if(view.getId()==R.id.addtodb) {

                    if (course_term.equals("1st term")) {
                        if (course_Id.equals("CS161") || course_Id.equals("CS225") ||
                                course_Id.equals("CS223") || course_Id.equals("CS277") || course_Id.equals("CS340") ||
                                course_Id.equals("CS364")) {
                            Toast.makeText(getApplicationContext(),"registered and added to database", Toast.LENGTH_LONG).show();
                            myDatabaseHandler.addcourse(new CourseModels(courses.getCOURSE_DESC(), courses.getTerm(), courses.getCOURSEPERREQUITES1(), courses.getCOURSEID(), courses.getCOURSEPREREQUIEST2()));
                            clean();
                        }
                        if (course_Id.equals("CS255")) {
                            Toast.makeText(getApplicationContext(), "Already Registered ", Toast.LENGTH_LONG).show();
                        }
                        else if (course_Id.contains("CS356")&& course_term.equals("1st term")) {
                            Toast.makeText(getApplicationContext(), "Incomplete Prerequisites", Toast.LENGTH_SHORT).show();
                        }
                    } else {

                        //        For registering courses for term2
                        if (course_Id.equals("CS128") | course_Id.equals("CS162")
                                || course_Id.equals("CS215") || course_Id.equals("CS275")) {
                            Toast.makeText(getApplicationContext(),"registered and added to database", Toast.LENGTH_SHORT).show();
                            myDatabaseHandler.addcourse(new CourseModels(courses.getCOURSE_DESC(), courses.getTerm(), courses.getCOURSEPERREQUITES1(), courses.getCOURSEID(), courses.getCOURSEPREREQUIEST2()));
                            clean();

                        }
                        if (course_Id.equals("CS263")) {
                            Toast.makeText(getApplicationContext(), "Preregistered Course", Toast.LENGTH_SHORT).show();
                        }

                        if (course_Id.equals("CS356") && course_term.equals("2nd term")) {
                            addmycourseestoDB();
                            clean();
                        }
                    }
                }
            if(view .getId()==R.id.emovedatbase) {
                if (course_Id.equals(("CS255")) || course_Id.equals(("CS263"))) {
                    Toast.makeText(getApplicationContext(), "Prerequisites cannnot be deleteed", Toast.LENGTH_SHORT).show();
                }
                if (course_Id.equals("CS161") || course_Id.equals("CS225") ||
                        course_Id.equals("CS223")  || course_Id.equals("CS340") ||
                        course_Id.equals("CS364")|| course_Id.equals("CS128")||course_Id.equals("CS162")||course_Id.equals("CS215")||
                        course_Id.equals("CS275")|| course_Id.equals("CS356"))
                {
                    Toast.makeText(getApplicationContext(),"Removed from Database", Toast.LENGTH_SHORT).show();
                    myDatabaseHandler.deletecourse(course_Id);
                    clean();
                }
                if(course_Id. equals("CS277"))
                {
                    myDatabaseHandler.deletecourse(course_Id);
                    List<CourseModels> array= myDatabaseHandler.getallcourses();
                    for (int i=0;i<array.size();i++)
                    {
                        if(array.get(i).getCOURSEID().equals("CS356")&& array.get(i).getTerm().equals("2nd term"))
                        {
                            myDatabaseHandler.deletecourse("CS356");
                            clean();
                        }
                    }

                }
            }
    }


   void clean()
   {
       Intent tomaiin= new Intent(getApplicationContext(),MainActivity.class);
       startActivity(tomaiin);
       finish();
   }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        clean();
    }

    private void addmycourseestoDB() {
        CourseModels courses = new CourseModels(course_des, course_term, prerequisite1, course_Id, prerequisite2);
     MyDatabaseHandler db=new MyDatabaseHandler(this);
        List<CourseModels> array= db.getallcourses();
        for(int i=0; i< array.size();i++)
        {
            if(array.get(i).getCOURSEID().equals("CS277"))
            {
                Toast.makeText(getApplicationContext(),"registered and added to database", Toast.LENGTH_LONG).show();
                db.addcourse(new CourseModels(courses.getCOURSE_DESC(), courses.getTerm(), courses.getCOURSEPERREQUITES1(), courses.getCOURSEID(), courses.getCOURSEPREREQUIEST2()));
                clean();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Not Added Prerequisite", Toast.LENGTH_SHORT).show();
            }
        }

    }
    private void connect() {
        JSONObject obj = new JSONObject();


        try {
            obj.put("student_id", "151");


            obj.put("name", "Shreya");

            obj.put("email", "shreya@stfx.ca");

            obj.put("course ", course_des); //course names separated by comma
            Log.d("Sending", course_des);
            URL url = new URL("http://35.203.95.76:8809/register/");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            String jsonInputString = new Gson().toJson(obj);
            connection.setRequestMethod("POST");

            connection.setConnectTimeout(2000);

            connection.setDoInput(true);

            connection.setRequestProperty("Content-Type", "application/json");

            connection.setRequestProperty("Accept", "application/json");
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);

                BufferedReader br = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                System.out.println(response.toString());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    }





