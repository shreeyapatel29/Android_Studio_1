package myapp.com.assignmentproject3;

class CourseModels {
    String COURSE_DESC;
    String term;
    String COURSEPERREQUITES1;
    String COURSEID;
    String COURSEPREREQUIEST2;
    String condition;
    String courseImg;

    public void setCourseImg(String courseImg) {
        this.courseImg = courseImg;
    }

    public String getCourseImg() {
        return courseImg;
    }

    public CourseModels(String course_des, String term, String prerequisite1, String course_Id, String prerequisite2, String condition, String courseImg) {
        this.COURSE_DESC = course_des;
        this.term = term;
        this.COURSEPERREQUITES1 = prerequisite1;
        this.COURSEID = course_Id;
        this.COURSEPREREQUIEST2 = prerequisite2;
        this.condition = condition;
        this.courseImg = courseImg;

    }

    public CourseModels(String course_des, String term, String prerequisite1, String course_Id, String prerequisite2) {
        this.COURSE_DESC = course_des;
        this.term = term;
        this.COURSEID = course_Id;
        this.COURSEPERREQUITES1 = prerequisite1;
        this.COURSEPREREQUIEST2 = prerequisite2;
    }

    public CourseModels() {

    }

    public String getCOURSE_DESC() {
        return COURSE_DESC;
    }

    public void setCOURSE_DESC(String COURSE_DESC) {
        this.COURSE_DESC = COURSE_DESC;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getCOURSEPERREQUITES1() {
        return COURSEPERREQUITES1;
    }

    public void setCOURSEPERREQUITES1(String COURSEPERREQUITES1) {
        this.COURSEPERREQUITES1 = COURSEPERREQUITES1;
    }

    public String getCOURSEID() {
        return COURSEID;
    }

    public void setCOURSEID(String COURSEID) {
        this.COURSEID = COURSEID;
    }

    public String getCOURSEPREREQUIEST2() {
        return COURSEPREREQUIEST2;
    }

    public void setCOURSEPREREQUIEST2(String COURSEPREREQUIEST2) {
        this.COURSEPREREQUIEST2 = COURSEPREREQUIEST2;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

}
