package myapp.com.assignmentproject3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import org.json.JSONException;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class MyAllCoursesListes extends Fragment {
    View view = null;

    ArrayList<CourseModels> courseList = new ArrayList<>();
    private RecycleerAdapter recyleAdapterdata;
    final String apiURl = "http://35.203.95.76:8809/course-details/";

    public MyAllCoursesListes() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_allcourses, container, false);
        recyleAdapterdata = new RecycleerAdapter(courseList);
        preparecourseData();
        RecyclerView recyvleview = (RecyclerView) view.findViewById(R.id.courselv);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(getContext());
        recyvleview.setHasFixedSize(true);
        recyvleview.setLayoutManager(lm);
        recyleAdapterdata.setCourseList(courseList);
        recyvleview.setAdapter(recyleAdapterdata);


        recyvleview.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), recyvleview, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                CourseModels cInfo = courseList.get(position);
                Toast.makeText(getActivity(), cInfo.getCOURSE_DESC() + " is selected!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity().getApplication(), CourseDeatilsActivityFull.class);


                intent.putExtra("COURSE_DESC", cInfo.getCOURSE_DESC());
                intent.putExtra("COURSEID", cInfo.getCOURSEID());
                intent.putExtra("course_term", cInfo.getTerm());
                intent.putExtra("COURSEPERREQUITES1", cInfo.getCOURSEPERREQUITES1());
                intent.putExtra("COURSEPREREQUIEST2", cInfo.getCOURSEPREREQUIEST2());
                intent.putExtra("condi", cInfo.getCondition());
                intent.putExtra("COURSE_IMG", cInfo.getCourseImg());
                startActivity(intent);

                getActivity().finish();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    private void preparecourseData() {
        HttpGetRequest httpGetRequest = new HttpGetRequest();
        try {
            String result = httpGetRequest.execute(apiURl).get();
            Log.d("Response", result);
            List<HashMap> courses = (List<HashMap>) new Gson().fromJson(result, ArrayList.class);
            Log.d("Number Of Courses ", "" + courses.size());
            for (int i = 0; i < courses.size(); i++) {
                CourseModels course = new CourseModels();
                Map courseHashmap = courses.get(i);
                course.setCOURSEPERREQUITES1((String) courseHashmap.get("prerequitiesOne"));
                course.setTerm((String) courseHashmap.get("term"));
                course.setCOURSE_DESC((String) courseHashmap.get("coursename"));
                course.setCOURSEID((String) courseHashmap.get("courseNumber"));
                course.setCourseImg((String) courseHashmap.get("imageUrl"));

                courseList.add(course);
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        recyleAdapterdata.notifyDataSetChanged();
    }


}
