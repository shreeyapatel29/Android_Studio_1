package myapp.com.assignmentproject3;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class RecycleerAdapter extends RecyclerView.Adapter<RecycleerAdapter.MyViewHolder> {

    private List<CourseModels> courseList;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView courseId, courseName, coursterm;
        public ImageView crImg;

        public MyViewHolder(View view) {
            super(view);
            crImg = (ImageView) view.findViewById(R.id.courseImg);
            courseId = (TextView) view.findViewById(R.id.courseId);
            courseName = (TextView) view.findViewById(R.id.courseName);
            coursterm = (TextView) view.findViewById(R.id.coursterm);
        }
    }


    public void setCourseList(List<CourseModels> courseList) {
        this.courseList = courseList;
    }

    public RecycleerAdapter(List<CourseModels> courseList) {
        this.courseList = courseList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final int pos = viewType;
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recykleinside, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        CourseModels course = courseList.get(position);
       //Picasso.get().load(course.getCourseImg()).into(holder.crImg);
        holder.courseId.setText(course.getCOURSEID());
        holder.courseName.setText(course.getCOURSE_DESC());
        holder.coursterm.setText(course.getTerm());
        if(holder.crImg!=null)
        {

            Picasso.get().load(course.getCourseImg()).into(holder.crImg);
        }
     //  Log.d("Image",course.getCourseImg());
    }

    @Override
    public int getItemCount() {
        return courseList.size();
    }
}
