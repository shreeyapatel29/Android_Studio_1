package myapp.com.assignmentproject3;


import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


/**
 * A simple {@link Fragment} subclass.
 */
public class AllAddedCoursesFragment extends Fragment {
    View view = null;
    ArrayList<CourseModels> ARRYLIT = new ArrayList<>();
    private RecycleerAdapter mAdapter;

    public AllAddedCoursesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_registeredcourses, container, false);
        CourseModels c2= new CourseModels("Advanced Data Structure","1st term","CS162","CS255","NAN");
        c2.setCourseImg("https://cdn.shopify.com/s/files/1/2472/3474/files/product_a22_gallery01.jpg");
        CourseModels c3=new CourseModels("Computer Architecture and Organization", "2nd term", "CS255", "CS263", "NAN");
        c3.setCourseImg("https://cdn.shopify.com/s/files/1/2472/3474/files/product_a22_gallery01.jpg");
        ARRYLIT.add(c2);
        ARRYLIT.add(c3);


        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

    }

    @Override
    public void onResume() {
        super.onResume();
        adddata();
        mAdapter.notifyDataSetChanged();
    }

    private void adddata() {

        MyDatabaseHandler db = new MyDatabaseHandler(this.getContext());

        List<CourseModels> coursel=db.getallcourses();
        for(int i=0;i<coursel.size();i++)
        {
            CourseModels c1=new CourseModels(coursel.get(i).getCOURSE_DESC(),coursel.get(i).getTerm(), coursel.get(i).getCOURSEPERREQUITES1(),
                    coursel.get(i).getCOURSEID(),coursel.get(i).getCOURSEPREREQUIEST2());
            ARRYLIT.add(c1);
        }
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mAdapter = new RecycleerAdapter(ARRYLIT);
        RecyclerView view_list = (RecyclerView) view.findViewById(R.id.view_list);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(getContext());
      //  view_list.setHasFixedSize(true);
        view_list.setLayoutManager(lm);
        view_list.setAdapter(mAdapter);

        view_list.addOnItemTouchListener(new RecyclerTouchListener(getActivity(), view_list, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                CourseModels cInfo = ARRYLIT.get(position);
                Toast.makeText(getActivity(), cInfo.getCOURSE_DESC() + " is selected!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity().getApplication(), CourseDeatilsActivityFull.class);


                intent.putExtra("COURSE_DESC",cInfo.getCOURSE_DESC());
                intent.putExtra("COURSEID",cInfo.getCOURSEID());
                intent.putExtra("course_term",cInfo.getTerm());
                intent.putExtra("COURSEPERREQUITES1",cInfo.getCOURSEPERREQUITES1());
                intent.putExtra("COURSEPREREQUIEST2",cInfo.getCOURSEPREREQUIEST2());
                intent.putExtra("condi",cInfo.getCondition());
                intent.putExtra("courseImage",cInfo.getCourseImg());
                startActivity(intent);
                getActivity().finish();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

    }
}

